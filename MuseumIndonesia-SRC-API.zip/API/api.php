<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: X-Requested-With");
// header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header("Content-Type:application/json");

require_once __DIR__ . '/vendor/autoload.php';

// koneski dari localhost server mongodb
$manager = new MongoDB\Driver\Manager('mongodb://localhost:27017');
// select collection mongodb dan database -> func(manager, database, collection)
$col = new MongoDB\Collection($manager, 'museum', 'data');
// select semua data
$data = $col->find();

// proses konversi ke array
// pilih hanya data yang di butuhkan
$res = array();
foreach ($data as $current) {
    $res[] = [
        "id_museum" => strval($current['_id']), // Object id dari mongodb konversi ke string tanpa prefix oid
        "img_museum" => $current['img_museum'],
        "nama_museum" => $current['nama_museum'],
        "alamat_museum" => $current['alamat_museum'],
        "wilayah_museum" => $current['wilayah_museum'],
        "jenis_museum" => $current['jenis_museum'],
        "tipe_museum" => $current['tipe_museum'],
        "pemilik_museum" => $current['pemilik_museum'],
        "pengelola_museum" => $current['pengelola_museum'],
        "sejarah_museum" => $current['sejarah_museum'],
        "lokasi_museum" => $current['lokasi_museum'],
        "jadwal_museum" => $current['jadwal_museum']
    ];
}
// post ke json
echo json_encode($res);
